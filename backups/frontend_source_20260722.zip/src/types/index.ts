// Core data types for GRT Portal

export type Role = "member" | "admin" | "collector";

export interface User {
  id: string; // The username (e.g. 202601)
  memberId: string; // The same as id
  password: string; // Random 8 numbers
  name: string;
  mobile: string;
  whatsapp: string;
  collectorName: string;
  profilePhoto?: string;
  role: Role;
  adminId?: string; // assigned collector (for members)
  isCollector?: boolean;
  registrationFeePaid: boolean;
  joinedAt: string; // ISO date
  nomineeName?: string; // Nominee full name
  nomineeRelation?: string; // Relation with nominee
  nomineeAddress?: string; // Nominee address
  nomineeContact?: string; // Nominee contact number
  shares?: number; // default to 1, multiplier for 100/mo
}

export interface Admin {
  id: string;
  name: string;
  username?: string;
  role: string | null;
  mobile: string | null;
  whatsapp: string | null;
  password?: string;
}

export type TransactionStatus = string;

export interface Transaction {
  id: string;
  memberId: string;
  adminId?: string;
  collectorName?: string;
  type: "registration" | "monthly";
  amount: number;
  monthKey?: string; // e.g. "2026-07" for monthly
  paidAt: string; // ISO
  receiptNo: string;
  status: string;
  transferredToTreasurer: boolean;
  transferBatchId?: string;
  approved?: boolean;
}

export interface ProfitEntry {
  id: string;
  amount: number;
  date: string; // ISO
}

export interface Investment {
  id: string;
  name: string;
  description: string;
  capitalDeployed: number;
  profitEntries: ProfitEntry[]; // list of periodic profits
  status: "active" | "closed";
}

export interface MemberInvestmentStake {
  memberId: string;
  investmentId: string;
  sharePct: number; // 0-100
}

export interface TreasurerTransfer {
   id: string;
   adminId: string;
   amount: number;
   transferredAt: string; // ISO
   batchId: string;
   transactionIds: string[];
}

export interface Expense {
   id: string;
   description: string;
   amount: number;
   category: string;
   date: string; // ISO
   addedBy: string; // admin name
   notes?: string;
}

export interface AppState {
   currentUserId: string | null; // logged-in email/id
   currentRole: Role; // dev role switcher
   members: User[];
   admins: Admin[];
   transactions: Transaction[];
   investments: Investment[];
   stakes: MemberInvestmentStake[];
   transfers: TreasurerTransfer[];
   expenses: Expense[];
   pendingSignups: { name: string; joinedAt: string }[];
}
