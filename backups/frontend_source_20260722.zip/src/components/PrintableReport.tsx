import { fmt, fmtDate, fmtMonthKey } from "@/lib/format";
import { AppState } from "@/types";

export const PrintableReport = ({ state }: { state: AppState }) => {
    const rows = state.members.map((m, idx) => {
        const memberTxns = state.transactions.filter(
            (t) => (t.memberId === m.id || t.memberId === m.memberId) && t.approved,
        );
        const totalCollected = memberTxns.reduce((sum, t) => sum + Number(t.amount || 0), 0);
        // Collect unique month labels
        const months = [
            ...new Set(memberTxns.map((t) => t.monthKey).filter(Boolean)),
        ]
            .sort()
            .map((mk) => fmtMonthKey(mk as string))
            .join(', ');
        return { m, totalCollected, months, idx };
    });

    const grandTotal = rows.reduce((sum, r) => sum + r.totalCollected, 0);

    return (
        <div className="hidden print:block p-8" id="printable-report">
            <style>{`
                @media print {
                    @page { size: A4; margin: 15mm; }
                    body * { visibility: hidden; }
                    #printable-report, #printable-report * { visibility: visible; }
                    #printable-report { position: absolute; left: 0; top: 0; width: 100%; font-size: 11px; }
                }
            `}</style>
            <div style={{ borderBottom: '2px solid #1a5276', marginBottom: 16, paddingBottom: 8 }}>
                <h1 style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>GRT-Grow Rich Together – Member Report</h1>
                <p style={{ margin: '4px 0 0', fontSize: 11, color: '#555' }}>
                    Generated on: {new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}
                </p>
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                <thead>
                    <tr style={{ backgroundColor: '#1a5276', color: '#fff' }}>
                        <th style={{ padding: '6px 8px', textAlign: 'left', border: '1px solid #aaa' }}>S.No</th>
                        <th style={{ padding: '6px 8px', textAlign: 'left', border: '1px solid #aaa' }}>User ID</th>
                        <th style={{ padding: '6px 8px', textAlign: 'left', border: '1px solid #aaa' }}>Member Name</th>
                        <th style={{ padding: '6px 8px', textAlign: 'center', border: '1px solid #aaa' }}>Shares</th>
                        <th style={{ padding: '6px 8px', textAlign: 'left', border: '1px solid #aaa' }}>Collector</th>
                        <th style={{ padding: '6px 8px', textAlign: 'left', border: '1px solid #aaa' }}>Mobile</th>
                        <th style={{ padding: '6px 8px', textAlign: 'left', border: '1px solid #aaa' }}>Month(s) of Payment</th>
                        <th style={{ padding: '6px 8px', textAlign: 'right', border: '1px solid #aaa' }}>Total Collected</th>
                    </tr>
                </thead>
                <tbody>
                    {rows.map(({ m, totalCollected, months, idx }) => (
                        <tr key={m.id} style={{ backgroundColor: idx % 2 === 0 ? '#f9f9f9' : '#fff' }}>
                            <td style={{ padding: '5px 8px', border: '1px solid #ddd', textAlign: 'center' }}>{idx + 1}</td>
                            <td style={{ padding: '5px 8px', border: '1px solid #ddd', fontFamily: 'monospace' }}>{m.memberId}</td>
                            <td style={{ padding: '5px 8px', border: '1px solid #ddd' }}>{m.name}</td>
                            <td style={{ padding: '5px 8px', border: '1px solid #ddd', textAlign: 'center' }}>{m.shares || 1} ({Number(m.shares || 1) * 100}/mo)</td>
                            <td style={{ padding: '5px 8px', border: '1px solid #ddd' }}>{m.collectorName || '—'}</td>
                            <td style={{ padding: '5px 8px', border: '1px solid #ddd', fontFamily: 'monospace' }}>{m.mobile}</td>
                            <td style={{ padding: '5px 8px', border: '1px solid #ddd', fontSize: 10 }}>{months || '—'}</td>
                            <td style={{ padding: '5px 8px', border: '1px solid #ddd', textAlign: 'right', fontWeight: 600 }}>
                                {fmt(totalCollected)}
                            </td>
                        </tr>
                    ))}
                </tbody>
                <tfoot>
                    <tr style={{ backgroundColor: '#d5e8d4', fontWeight: 700 }}>
                        <td colSpan={6} style={{ padding: '7px 8px', border: '1px solid #aaa', textAlign: 'right' }}>
                            Grand Total Collected
                        </td>
                        <td style={{ padding: '7px 8px', border: '1px solid #aaa', textAlign: 'right' }}>
                            {fmt(grandTotal)}
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    );
};
